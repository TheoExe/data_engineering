from shared.shared import afunction, clean_string, space_compress
